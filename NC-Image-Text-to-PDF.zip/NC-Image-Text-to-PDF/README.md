# Image & Text to PDF

A lightweight Python desktop application for converting images and text files into PDF documents.

## Features

- Import multiple images and text files.
- Import files from folders.
- Arrange files in your preferred order.
- Move files up and down.
- Remove individual files or clear the entire list.
- Automatically number the file order.
- Convert everything into a single PDF.
- Automatically split long text across multiple PDF pages.
- Fit images onto A4 pages without stretching.

## Supported Image Formats

- PNG
- JPG / JPEG
- BMP
- GIF
- TIFF
- WEBP
- ICO
- JFIF

## Supported Text Formats

- TXT
- MD
- CSV
- TSV
- LOG
- JSON
- XML
- HTML
- CSS
- JavaScript
- Python
- Java
- C / C++
- YAML
- INI
- BAT / CMD
- And more.

## Requirements

- Python 3
- Pillow
- ReportLab

## Installation

1. Download or clone this repository.
2. Run `RUN.bat`.
3. Wait for the required Python libraries to install.
4. The application will launch automatically.

## Usage

1. Click **Add Files** or **Add Folder**.
2. Select your images and text files.
3. Arrange their order using **Move Up** and **Move Down**.
4. Click **CREATE PDF**.
5. Choose where to save your PDF.

## Project Structure

```text
Image-Text-to-PDF/
├── image_text_to_pdf.py
├── RUN.bat
├── README.md
└── LICENSE
```

## License

MIT License.

## Author

Created as an independent Python project.
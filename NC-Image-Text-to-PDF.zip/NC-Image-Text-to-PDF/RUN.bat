
@echo off
title Image and Text to PDF

cd /d "%~dp0"

echo ====================================
echo       IMAGE AND TEXT TO PDF
echo ====================================
echo.

where py >nul 2>nul

if %errorlevel%==0 (
    set "PYTHON=py"
) else (
    where python >nul 2>nul

    if errorlevel 1 (
        echo Python is not installed!
        echo Download it from:
        echo https://www.python.org/downloads/
        pause
        exit /b 1
    )

    set "PYTHON=python"
)

echo Installing required libraries...

%PYTHON% -m pip install Pillow reportlab

if errorlevel 1 (
    echo.
    echo Installation failed!
    pause
    exit /b 1
)

echo.
echo Starting application...

%PYTHON% image_text_to_pdf.py

if errorlevel 1 (
    echo.
    echo Application encountered an error.
    pause
)



import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase.pdfmetrics import stringWidth


IMAGE_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".bmp", ".gif",
    ".tif", ".tiff", ".webp", ".ico", ".jfif"
}

TEXT_EXTENSIONS = {
    ".txt", ".md", ".markdown", ".csv", ".tsv",
    ".log", ".json", ".xml", ".html", ".htm",
    ".css", ".js", ".py", ".java", ".c", ".cpp",
    ".h", ".cs", ".php", ".sql", ".yaml", ".yml",
    ".ini", ".cfg", ".conf", ".bat", ".cmd",
    ".sh", ".ps1"
}


class ImageTextPDF:

    def __init__(self, root):
        self.root = root
        self.root.title("Image & Text to PDF")
        self.root.geometry("850x600")
        self.root.minsize(650, 450)

        self.files = []

        self.create_interface()

    def create_interface(self):

        main = ttk.Frame(self.root, padding=15)
        main.pack(fill="both", expand=True)

        ttk.Label(
            main,
            text="Image & Text to PDF",
            font=("Segoe UI", 20, "bold")
        ).pack(anchor="w")

        ttk.Label(
            main,
            text="Import files, arrange their order, and create your PDF."
        ).pack(anchor="w", pady=(3, 15))

        # Toolbar

        toolbar = ttk.Frame(main)
        toolbar.pack(fill="x", pady=5)

        ttk.Button(
            toolbar,
            text="Add Files",
            command=self.add_files
        ).pack(side="left", padx=3)

        ttk.Button(
            toolbar,
            text="Add Folder",
            command=self.add_folder
        ).pack(side="left", padx=3)

        ttk.Button(
            toolbar,
            text="Remove Selected",
            command=self.remove_selected
        ).pack(side="left", padx=3)

        ttk.Button(
            toolbar,
            text="Clear All",
            command=self.clear_all
        ).pack(side="left", padx=3)

        # File list

        content = ttk.Frame(main)
        content.pack(fill="both", expand=True, pady=10)

        self.listbox = tk.Listbox(
            content,
            font=("Segoe UI", 11),
            selectmode=tk.EXTENDED,
            activestyle="dotbox"
        )

        self.listbox.pack(
            side="left",
            fill="both",
            expand=True
        )

        scrollbar = ttk.Scrollbar(
            content,
            command=self.listbox.yview
        )

        scrollbar.pack(side="left", fill="y")

        self.listbox.config(
            yscrollcommand=scrollbar.set
        )

        # Arrangement controls

        controls = ttk.Frame(content, padding=12)
        controls.pack(side="left", fill="y")

        ttk.Label(
            controls,
            text="Arrange Order",
            font=("Segoe UI", 11, "bold")
        ).pack(pady=5)

        ttk.Button(
            controls,
            text="Move Up ↑",
            command=lambda: self.move_selected(-1)
        ).pack(fill="x", pady=4)

        ttk.Button(
            controls,
            text="Move Down ↓",
            command=lambda: self.move_selected(1)
        ).pack(fill="x", pady=4)

        ttk.Separator(controls).pack(fill="x", pady=10)

        ttk.Label(
            controls,
            text="PDF Order:\n1 → 2 → 3 → 4 → ...",
            justify="left"
        ).pack(anchor="w")

        # Bottom controls

        bottom = ttk.Frame(main)
        bottom.pack(fill="x", pady=10)

        self.status = tk.StringVar(
            value="Ready. Add some files!"
        )

        ttk.Label(
            bottom,
            textvariable=self.status
        ).pack(side="left")

        ttk.Button(
            bottom,
            text="CREATE PDF",
            command=self.create_pdf
        ).pack(side="right")

    # ----------------------------
    # FILE IMPORT
    # ----------------------------

    def add_files(self):

        paths = filedialog.askopenfilenames(
            title="Select files",
            filetypes=[
                ("Supported files", "*.png *.jpg *.jpeg *.bmp *.gif "
                 "*.tif *.tiff *.webp *.ico *.jfif *.txt *.md *.csv "
                 "*.json *.xml *.html *.css *.js *.py *.java *.cpp "
                 "*.yaml *.yml *.ini *.bat *.cmd *.log"),
                ("All files", "*.*")
            ]
        )

        self.add_paths(paths)

    def add_folder(self):

        folder = filedialog.askdirectory()

        if not folder:
            return

        paths = [
            str(p) for p in sorted(Path(folder).iterdir())
            if p.is_file()
        ]

        self.add_paths(paths)

    def add_paths(self, paths):

        existing = {
            item["path"] for item in self.files
        }

        added = 0

        for path in paths:

            p = Path(path)
            ext = p.suffix.lower()

            if ext in IMAGE_EXTENSIONS:
                kind = "Image"

            elif ext in TEXT_EXTENSIONS:
                kind = "Text"

            else:
                continue

            full_path = str(p.resolve())

            if full_path in existing:
                continue

            self.files.append({
                "path": full_path,
                "kind": kind
            })

            existing.add(full_path)
            added += 1

        self.refresh()

        self.status.set(
            f"{len(self.files)} files loaded. Added {added}."
        )

    # ----------------------------
    # LIST MANAGEMENT
    # ----------------------------

    def refresh(self, selection=None):

        self.listbox.delete(0, tk.END)

        for index, item in enumerate(self.files, 1):

            name = Path(item["path"]).name

            self.listbox.insert(
                tk.END,
                f"{index}. [{item['kind']}] {name}"
            )

        if selection:

            for index in selection:

                if 0 <= index < len(self.files):
                    self.listbox.selection_set(index)

    def remove_selected(self):

        selected = list(
            self.listbox.curselection()
        )

        for index in reversed(selected):
            del self.files[index]

        self.refresh()

        self.status.set(
            f"{len(self.files)} files remaining."
        )

    def clear_all(self):

        self.files.clear()

        self.refresh()

        self.status.set("All files removed.")

    def move_selected(self, direction):

        selected = list(
            self.listbox.curselection()
        )

        if not selected:
            return

        if direction < 0:

            for index in selected:

                target = index - 1

                if target >= 0 and target not in selected:

                    self.files[index], self.files[target] = (
                        self.files[target],
                        self.files[index]
                    )

                    selected = [
                        target if x == index else x
                        for x in selected
                    ]

        else:

            for index in reversed(selected):

                target = index + 1

                if (
                    target < len(self.files)
                    and target not in selected
                ):

                    self.files[index], self.files[target] = (
                        self.files[target],
                        self.files[index]
                    )

                    selected = [
                        target if x == index else x
                        for x in selected
                    ]

        self.refresh(sorted(selected))

    # ----------------------------
    # TEXT PROCESSING
    # ----------------------------

    def read_text(self, path):

        data = Path(path).read_bytes()

        for encoding in (
            "utf-8-sig",
            "utf-8",
            "cp1252",
            "latin-1"
        ):

            try:
                return data.decode(encoding)

            except UnicodeDecodeError:
                continue

        return data.decode(
            "utf-8",
            errors="replace"
        )

    def wrap_text(self, text, font, size, width):

        lines = []

        for original in text.splitlines() or [""]:

            if not original:
                lines.append("")
                continue

            words = original.split()
            line = ""

            for word in words:

                candidate = (
                    word if not line
                    else line + " " + word
                )

                if stringWidth(
                    candidate, font, size
                ) <= width:

                    line = candidate

                else:

                    if line:
                        lines.append(line)

                    line = word

            lines.append(line)

        return lines

    def add_text(self, pdf, path):

        page_w, page_h = A4

        margin = 45
        font = "Courier"
        font_size = 8
        line_height = 11

        max_width = page_w - margin * 2

        text = self.read_text(path)

        pdf.setFont("Helvetica-Bold", 14)

        pdf.drawString(
            margin,
            page_h - margin,
            Path(path).name[:100]
        )

        y = page_h - margin - 25

        pdf.setFont(font, font_size)

        lines = self.wrap_text(
            text,
            font,
            font_size,
            max_width
        )

        for line in lines:

            if y < margin:

                pdf.showPage()

                pdf.setFont(font, font_size)

                y = page_h - margin

            pdf.drawString(
                margin,
                y,
                line
            )

            y -= line_height

        pdf.showPage()

    # ----------------------------
    # IMAGE PROCESSING
    # ----------------------------

    def add_image(self, pdf, path):

        page_w, page_h = A4

        margin = 25

        with Image.open(path) as source:

            image = source.copy()

            if image.mode not in ("RGB", "L"):

                rgba = image.convert("RGBA")

                background = Image.new(
                    "RGBA",
                    rgba.size,
                    "white"
                )

                background.alpha_composite(rgba)

                image = background.convert("RGB")

            elif image.mode == "L":

                image = image.convert("RGB")

            max_w = page_w - margin * 2
            max_h = page_h - margin * 2

            scale = min(
                max_w / image.width,
                max_h / image.height
            )

            draw_w = image.width * scale
            draw_h = image.height * scale

            x = (page_w - draw_w) / 2
            y = (page_h - draw_h) / 2

            pdf.drawImage(
                ImageReader(image),
                x,
                y,
                width=draw_w,
                height=draw_h
            )

        pdf.showPage()

    # ----------------------------
    # PDF GENERATION
    # ----------------------------

    def create_pdf(self):

        if not self.files:

            messagebox.showwarning(
                "Empty List",
                "Please add some files first."
            )

            return

        output = filedialog.asksaveasfilename(
            title="Save PDF",
            defaultextension=".pdf",
            initialfile="Converted_Files.pdf",
            filetypes=[
                ("PDF Files", "*.pdf")
            ]
        )

        if not output:
            return

        try:

            pdf = canvas.Canvas(
                output,
                pagesize=A4
            )

            pdf.setTitle("Image and Text PDF")

            for item in self.files:

                path = item["path"]

                if not os.path.isfile(path):
                    raise FileNotFoundError(path)

                if item["kind"] == "Image":

                    self.add_image(pdf, path)

                else:

                    self.add_text(pdf, path)

            pdf.save()

            self.status.set(
                f"PDF created: {output}"
            )

            messagebox.showinfo(
                "Success",
                f"Your PDF was created successfully!\n\n{output}"
            )

        except Exception as error:

            messagebox.showerror(
                "PDF Error",
                str(error)
            )


if __name__ == "__main__":

    root = tk.Tk()

    try:
        ttk.Style().theme_use("vista")
    except tk.TclError:
        pass

    app = ImageTextPDF(root)

    root.mainloop()
